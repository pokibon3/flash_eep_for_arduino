# arduino_test (CH32V)

このプロジェクトは CH32V03 系で動作する Flash EEPROM エミュレーションのライブラリです。  
使用方法はexamplesのflash_test.inoを参照してください。
V1.0.1では、ライブラリ内でのインスタンス生成を廃止しましたので、スケッチ内でインスタンスを生成してください。


変更履歴
V1.0.0  2025/12/21 First Release 
V1.0.1　2025/12/24 Bug Fix
